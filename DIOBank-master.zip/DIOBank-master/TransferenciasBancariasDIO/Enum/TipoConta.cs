﻿// criado seguindo os passos do curso "Criando uma aplicação de transferências bancárias com .NET - Eliézer Zarpelão" - DIO
namespace TransferenciasBancariasDIO // pasta retirada
{
    public enum TipoConta
    {
        PessoaFisica = 1,
        PessoaJuridica = 2
    }
}
